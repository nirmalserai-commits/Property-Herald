import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import {
  ArrowRight, Bell, Check, Clock, KeyRound, Lock, Mail, MapPin,
  Sparkles, TrendingUp, User, Building2, Phone, AlertCircle, Loader2,
} from 'lucide-react';

const BETA_KEY = 'ph_beta_access_until';

type CodeState = 'idle' | 'verifying' | 'valid' | 'invalid' | 'expired';

function BetaAccess({ onUnlocked }: { onUnlocked: () => void }) {
  const [code, setCode] = useState('');
  const [cstate, setCstate] = useState<CodeState>('idle');
  const [message, setMessage] = useState('');

  async function handleRedeem(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = code.trim().toUpperCase();
    if (trimmed.length !== 8) {
      setCstate('invalid');
      setMessage('Access codes are 8 characters long.');
      return;
    }
    setCstate('verifying');
    setMessage('');

    const { data, error } = await supabase
      .from('access_codes')
      .select('id, code, is_used, used_at, expires_at')
      .eq('code', trimmed)
      .maybeSingle();

    if (error || !data) {
      setCstate('invalid');
      setMessage('That code is not recognised. Please check and try again.');
      return;
    }

    const now = new Date();

    if (data.is_used) {
      const exp = data.expires_at ? new Date(data.expires_at) : null;
      if (exp && exp > now) {
        sessionStorage.setItem(BETA_KEY, exp.toISOString());
        setCstate('valid');
        setMessage('Access already active — welcome back!');
        setTimeout(onUnlocked, 900);
        return;
      }
      setCstate('expired');
      setMessage('This code has already been used and its hour has expired.');
      return;
    }

    const expiresAt = new Date(now.getTime() + 60 * 60 * 1000);
    const { error: updateError } = await supabase
      .from('access_codes')
      .update({ is_used: true, used_at: now.toISOString(), expires_at: expiresAt.toISOString() })
      .eq('id', data.id);

    if (updateError) {
      setCstate('invalid');
      setMessage('Could not redeem code. Please try again.');
      return;
    }

    sessionStorage.setItem(BETA_KEY, expiresAt.toISOString());
    setCstate('valid');
    setMessage('Access granted! You have 1 hour of preview access.');
    setTimeout(onUnlocked, 1100);
  }

  const btnLabel = cstate === 'valid' ? 'Granted' : 'Unlock';
  const busy = cstate === 'verifying' || cstate === 'valid';

  return (
    <div className="w-full max-w-md">
      <div className="bg-navy/90 backdrop-blur rounded-2xl border border-gold/30 p-6 shadow-2xl">
        <label className="block text-xs font-display font-bold uppercase tracking-widest text-gold mb-3">
          Enter your exclusive access code
        </label>
        <form onSubmit={handleRedeem} className="flex gap-2">
          <div className="relative flex-1">
            <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gold/50" />
            <input
              value={code}
              onChange={(e) => { setCode(e.target.value.toUpperCase()); setCstate('idle'); }}
              placeholder="XXXXXXXX"
              maxLength={8}
              autoComplete="off"
              disabled={busy}
              className="w-full pl-9 pr-3 py-3 bg-navy-800 border border-gold/25 rounded-xl text-cream font-mono tracking-[0.3em] uppercase placeholder-cream/25 focus:outline-none focus:border-gold transition-colors disabled:opacity-60 text-center"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="px-5 py-3 bg-gold text-navy font-display font-bold rounded-xl hover:bg-gold-400 transition-all shadow-md disabled:opacity-60 flex items-center gap-2 whitespace-nowrap"
          >
            {cstate === 'verifying' ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
            <span className="hidden sm:inline">{btnLabel}</span>
          </button>
        </form>

        {cstate === 'valid' ? (
          <div className="mt-3 flex items-center gap-2 text-sm text-green-400">
            <Check className="w-4 h-4 flex-shrink-0" /> {message}
          </div>
        ) : (cstate === 'invalid' || cstate === 'expired') ? (
          <div className="mt-3 flex items-center gap-2 text-sm text-red-400">
            <AlertCircle className="w-4 h-4 flex-shrink-0" /> {message}
          </div>
        ) : (
          <p className="mt-3 text-xs text-cream/40 flex items-center gap-1.5">
            <Clock className="w-3 h-3" /> Each code grants 1 hour of preview access.
          </p>
        )}
      </div>
    </div>
  );
}

type InterestState = 'idle' | 'submitting' | 'done' | 'error';

function RegisterInterest() {
  const [form, setForm] = useState({ name: '', email: '', company: '', mobile: '' });
  const [istate, setIstate] = useState<InterestState>('idle');
  const [errMsg, setErrMsg] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim()) return;
    setIstate('submitting');
    const { error } = await supabase.from('beta_interest').insert({
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      company: form.company.trim() || null,
      mobile: form.mobile.trim() || null,
    });
    if (error) {
      if (error.code === '23505') {
        setErrMsg('You have already registered your interest with this email.');
      } else {
        setErrMsg('Something went wrong. Please try again.');
      }
      setIstate('error');
      return;
    }
    setIstate('done');
  }

  if (istate === 'done') {
    return (
      <div className="text-center py-8">
        <div className="w-14 h-14 rounded-full bg-gold/15 border border-gold/40 flex items-center justify-center mx-auto mb-4">
          <Check className="w-7 h-7 text-gold" />
        </div>
        <p className="text-cream font-serif text-lg mb-1">Interest Registered</p>
        <p className="text-cream/50 text-sm">We will reach out when developer and agency registration opens on July 25, 2026.</p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-3 w-full max-w-md">
      <div className="grid sm:grid-cols-2 gap-3">
        <Field icon={User} placeholder="Full name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
        <Field icon={Mail} placeholder="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
        <Field icon={Building2} placeholder="Company" value={form.company} onChange={(v) => setForm({ ...form, company: v })} />
        <Field icon={Phone} placeholder="Mobile" value={form.mobile} onChange={(v) => setForm({ ...form, mobile: v })} />
      </div>
      {istate === 'error' && (
        <div className="flex items-center gap-2 text-sm text-red-400">
          <AlertCircle className="w-4 h-4 flex-shrink-0" /> {errMsg}
        </div>
      )}
      <button
        type="submit"
        disabled={istate === 'submitting'}
        className="w-full py-3 bg-gold text-navy font-display font-bold rounded-xl hover:bg-gold-400 transition-all shadow-md disabled:opacity-60 flex items-center justify-center gap-2"
      >
        {istate === 'submitting' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        Register Interest
      </button>
    </form>
  );
}

type NotifyState = 'idle' | 'submitting' | 'done' | 'error';

function NotifyMe() {
  const [email, setEmail] = useState('');
  const [nstate, setNstate] = useState<NotifyState>('idle');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    setNstate('submitting');
    const { error } = await supabase.from('beta_notify').insert({ email: email.trim().toLowerCase() });
    if (error) {
      if (error.code === '23505') {
        setNstate('done');
        return;
      }
      setNstate('error');
      return;
    }
    setNstate('done');
  }

  if (nstate === 'done') {
    return (
      <div className="flex items-center justify-center gap-2 text-sm text-gold py-2">
        <Check className="w-4 h-4" /> You will be notified at launch.
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="flex gap-2 w-full max-w-md">
      <div className="relative flex-1">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/40" />
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="your@email.com"
          disabled={nstate === 'submitting'}
          className="w-full pl-9 pr-3 py-3 bg-navy-800 border border-gold/25 rounded-xl text-cream placeholder-cream/30 focus:outline-none focus:border-gold transition-colors disabled:opacity-60"
        />
      </div>
      <button
        type="submit"
        disabled={nstate === 'submitting'}
        className="px-5 py-3 bg-gold/15 border border-gold/40 text-gold font-display font-bold rounded-xl hover:bg-gold/25 transition-all disabled:opacity-60 flex items-center gap-2 whitespace-nowrap"
      >
        {nstate === 'submitting' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />}
        <span className="hidden sm:inline">Notify Me</span>
      </button>
      {nstate === 'error' && <p className="text-xs text-red-400 mt-1">Could not save. Please try again.</p>}
    </form>
  );
}

function Field({
  icon: Icon, placeholder, value, onChange, type = 'text', required,
}: {
  icon: typeof User; placeholder: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean;
}) {
  return (
    <div className="relative">
      <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cream/40" />
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        className="w-full pl-9 pr-3 py-3 bg-navy-800 border border-gold/25 rounded-xl text-cream placeholder-cream/30 focus:outline-none focus:border-gold transition-colors"
      />
    </div>
  );
}

const PHASES = [
  { phase: 1, date: 'NOW', title: 'Beta Access', status: 'live' as const,
    blurb: 'Enter your exclusive access code for 1 hour preview access.' },
  { phase: 2, date: 'JULY 25, 2026', title: 'Developer & Agency Registration Opens', status: 'upcoming' as const,
    blurb: 'Verified builders, agents, and agencies get early access to list on India\u2019s premier property platform.' },
  { phase: 3, date: 'AUGUST 15, 2026', title: 'Independence Day — Open to All India', status: 'upcoming' as const,
    blurb: 'Property Herald opens to every property seeker across the nation. Be the first to know.' },
];

export function ComingSoonPage({ onBetaUnlocked }: { onBetaUnlocked: () => void }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  function daysUntil(target: string): number {
    if (target === 'NOW') return 0;
    const d = new Date(target).getTime();
    return Math.max(0, Math.ceil((d - now.getTime()) / 86400000));
  }

  return (
    <div className="min-h-screen bg-navy text-cream flex flex-col">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-gold/5 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] rounded-full bg-gold/3 blur-3xl" />
      </div>

      <header className="relative z-10 flex flex-col items-center justify-center px-4 pt-20 pb-12 text-center">
        <div className="relative mb-8">
          <div className="absolute inset-[-4px] rounded-3xl bg-gold/10 blur-2xl" />
          <img
            src="/logo.png.png"
            alt="Property Herald"
            className="relative h-32 md:h-40 w-auto object-contain drop-shadow-2xl"
            onError={(e) => {
              const t = e.target as HTMLImageElement;
              t.style.display = 'none';
              const fb = t.nextElementSibling as HTMLElement;
              if (fb) fb.style.display = 'flex';
            }}
          />
          <div className="hidden h-32 md:h-40 w-auto aspect-square items-center justify-center bg-navy-800 border-2 border-gold/40 rounded-3xl p-8 gold-glow">
            <div className="text-center">
              <div className="text-5xl md:text-6xl font-serif font-black text-gold leading-none">PH</div>
              <div className="mt-1 font-display font-bold tracking-widest text-cream/80 text-xs uppercase">Property Herald</div>
            </div>
          </div>
        </div>

        <div className="inline-flex items-center px-4 py-2 rounded-full bg-gold/10 border border-gold/30 text-gold text-sm font-display font-semibold uppercase tracking-wider mb-5">
          <TrendingUp className="w-4 h-4 mr-2" /> Coming Soon
        </div>
        <h1 className="text-3xl md:text-5xl font-serif font-bold text-cream leading-tight mb-4 text-balance max-w-2xl">
          India\u2019s Premier Real Estate Intelligence Platform
        </h1>
        <p className="text-cream/60 text-base md:text-lg max-w-xl leading-relaxed mb-2">
          Discover. Connect. Grow. A curated, AI-powered directory connecting buyers with trusted builders and agencies nationwide.
        </p>
        <p className="text-gold/80 font-serif italic text-sm md:text-base">
          We are rolling out in three phases. Here is where we stand.
        </p>
      </header>

      <main className="relative z-10 flex-1 px-4 pb-16">
        <div className="max-w-4xl mx-auto space-y-5">
          {PHASES.map((p) => {
            const isLive = p.status === 'live';
            return (
              <div
                key={p.phase}
                className={`relative rounded-2xl border p-6 md:p-7 transition-all ${
                  isLive ? 'border-gold/50 bg-navy-800/80 shadow-xl shadow-gold/5' : 'border-gold/15 bg-navy-800/40'
                }`}
              >
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex md:flex-col items-center md:items-start gap-3 md:gap-1 md:w-40 flex-shrink-0">
                    <div className={`px-3 py-1 rounded-full text-xs font-display font-bold uppercase tracking-wider ${
                      isLive ? 'bg-gold text-navy animate-pulse' : 'bg-gold/10 text-gold/70 border border-gold/20'
                    }`}>
                      Phase {p.phase}
                    </div>
                    <div className={`text-sm font-display font-semibold ${isLive ? 'text-gold' : 'text-cream/50'}`}>{p.date}</div>
                    {!isLive && (
                      <div className="hidden md:flex items-center gap-1.5 text-xs text-cream/40">
                        <Clock className="w-3 h-3" /> {daysUntil(p.date)} days away
                      </div>
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {isLive ? <Sparkles className="w-5 h-5 text-gold" /> : <Lock className="w-4 h-4 text-gold/40" />}
                      <h2 className={`text-lg md:text-xl font-serif font-bold ${isLive ? 'text-cream' : 'text-cream/70'}`}>
                        {p.title}
                      </h2>
                    </div>
                    <p className="text-cream/55 text-sm mb-5 leading-relaxed">{p.blurb}</p>

                    {isLive ? (
                      <BetaAccess onUnlocked={onBetaUnlocked} />
                    ) : p.phase === 2 ? (
                      <RegisterInterest />
                    ) : (
                      <NotifyMe />
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <footer className="relative z-10 border-t border-gold/10 py-6 text-center px-4">
        <p className="text-cream/40 text-xs flex items-center justify-center gap-1.5">
          <MapPin className="w-3 h-3 text-gold/50" /> Made in India · Property Herald &copy; {now.getFullYear()}
        </p>
        <Link to="/login" className="mt-2 inline-flex items-center gap-1.5 text-cream/20 hover:text-gold text-xs transition-colors">
          <Lock className="w-3 h-3" /> Staff Login
        </Link>
      </footer>
    </div>
  );
}
