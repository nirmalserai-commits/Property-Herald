import { useState, useEffect, useCallback } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { supabase } from '../../lib/supabase';
import {
  KeyRound, RefreshCw, Copy, Check, Clock, Users, Mail,
  User, Building2, Phone, Calendar, Search,
} from 'lucide-react';

interface AccessCode {
  id: string;
  code: string;
  is_used: boolean;
  used_at: string | null;
  expires_at: string | null;
  created_at: string;
}

interface InterestRow {
  id: string;
  name: string;
  email: string;
  company: string | null;
  mobile: string | null;
  created_at: string;
}

interface NotifyRow {
  id: string;
  email: string;
  created_at: string;
}

type Tab = 'codes' | 'interest' | 'notify';

export function AdminBetaAccess() {
  const [tab, setTab] = useState<Tab>('codes');
  const [codes, setCodes] = useState<AccessCode[]>([]);
  const [interest, setInterest] = useState<InterestRow[]>([]);
  const [notify, setNotify] = useState<NotifyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const [codesRes, interestRes, notifyRes] = await Promise.all([
      supabase.from('access_codes').select('*').order('is_used', { ascending: true }).order('created_at'),
      supabase.from('beta_interest').select('*').order('created_at', { ascending: false }),
      supabase.from('beta_notify').select('*').order('created_at', { ascending: false }),
    ]);
    if (codesRes.data) setCodes(codesRes.data as AccessCode[]);
    if (interestRes.data) setInterest(interestRes.data as InterestRow[]);
    if (notifyRes.data) setNotify(notifyRes.data as NotifyRow[]);
    setLastRefresh(new Date());
    setLoading(false);
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  function copyCode(code: string) {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1500);
  }

  const filteredCodes = search
    ? codes.filter(c => c.code.toLowerCase().includes(search.toLowerCase()))
    : codes;

  const usedCount = codes.filter(c => c.is_used).length;
  const activeCount = codes.filter(c => {
    if (!c.is_used || !c.expires_at) return false;
    return new Date(c.expires_at) > new Date();
  }).length;

  const TABS: { id: Tab; label: string; count: number }[] = [
    { id: 'codes', label: 'Access Codes', count: codes.length },
    { id: 'interest', label: 'Registration Interest', count: interest.length },
    { id: 'notify', label: 'Notify Me', count: notify.length },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-bold text-navy flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-gold" /> Beta Access
            </h2>
            <p className="text-sm text-gray-500 mt-0.5">
              Phased launch control — {usedCount}/{codes.length} codes redeemed · {activeCount} sessions active now
            </p>
          </div>
          <button
            onClick={fetchAll}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-navy text-cream rounded-xl text-sm font-medium hover:bg-navy/90 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === t.id ? 'bg-white text-navy shadow-sm' : 'text-gray-500 hover:text-navy'}`}
            >
              {t.label} <span className="text-xs text-gray-400">({t.count})</span>
            </button>
          ))}
        </div>

        {/* Codes tab */}
        {tab === 'codes' && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-2xl border border-gray-100 p-4 text-center">
                <p className="text-2xl font-bold text-navy">{codes.length}</p>
                <p className="text-xs text-gray-500 mt-0.5">Total Codes</p>
              </div>
              <div className="bg-amber-50 rounded-2xl border border-amber-100 p-4 text-center">
                <p className="text-2xl font-bold text-amber-700">{usedCount}</p>
                <p className="text-xs text-amber-600 mt-0.5">Redeemed</p>
              </div>
              <div className="bg-green-50 rounded-2xl border border-green-100 p-4 text-center">
                <p className="text-2xl font-bold text-green-700">{activeCount}</p>
                <p className="text-xs text-green-600 mt-0.5">Active Now</p>
              </div>
            </div>

            {/* Search */}
            <div className="relative max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search codes…"
                className="w-full pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-navy focus:outline-none focus:border-gold transition-colors"
              />
            </div>

            {/* Codes grid */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              {loading ? (
                <div className="p-8 text-center">
                  <div className="w-6 h-6 border-2 border-navy/20 border-t-navy rounded-full animate-spin mx-auto" />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-px bg-gray-100">
                  {filteredCodes.map(c => {
                    const isActive = c.is_used && c.expires_at && new Date(c.expires_at) > new Date();
                    const isExpired = c.is_used && (!c.expires_at || new Date(c.expires_at) <= new Date());
                    return (
                      <div key={c.id} className="bg-white p-4 flex flex-col items-center gap-2">
                        <div className="flex items-center gap-2">
                          <code className={`font-mono font-bold text-lg tracking-wider ${c.is_used ? 'text-gray-400' : 'text-navy'}`}>
                            {c.code}
                          </code>
                          <button onClick={() => copyCode(c.code)} className="text-gray-300 hover:text-gold transition-colors" title="Copy code">
                            {copiedCode === c.code ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                        {c.is_used ? (
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            isActive ? 'bg-green-50 text-green-700 border border-green-100' :
                            isExpired ? 'bg-red-50 text-red-600 border border-red-100' :
                            'bg-gray-50 text-gray-500 border border-gray-100'
                          }`}>
                            {isActive ? 'Active' : isExpired ? 'Expired' : 'Used'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gold/10 text-gold border border-gold/20">Available</span>
                        )}
                        {c.used_at && (
                          <p className="text-xs text-gray-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(c.used_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            <p className="text-xs text-gray-400 flex items-center gap-1.5">
              <Clock className="w-3 h-3" />
              Last refreshed: {lastRefresh.toLocaleTimeString()}
            </p>
          </div>
        )}

        {/* Interest tab */}
        {tab === 'interest' && (
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-navy flex items-center gap-2">
                <Users className="w-4 h-4 text-gold" /> Registration Interest
              </h3>
              <span className="text-sm text-gray-500">{interest.length} submissions</span>
            </div>
            {loading ? (
              <div className="p-8 text-center">
                <div className="w-6 h-6 border-2 border-navy/20 border-t-navy rounded-full animate-spin mx-auto" />
              </div>
            ) : interest.length === 0 ? (
              <div className="p-12 text-center text-gray-400 text-sm">No registrations yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      {['Name', 'Email', 'Company', 'Mobile', 'Submitted'].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {interest.map(r => (
                      <tr key={r.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 font-medium text-navy whitespace-nowrap flex items-center gap-2">
                          <User className="w-3.5 h-3.5 text-gray-400" />{r.name}
                        </td>
                        <td className="px-4 py-3 text-gray-600">{r.email}</td>
                        <td className="px-4 py-3 text-gray-600">{r.company || '—'}</td>
                        <td className="px-4 py-3 text-gray-600 whitespace-nowrap">{r.mobile || '—'}</td>
                        <td className="px-4 py-3 text-gray-400 text-xs whitespace-nowrap">
                          {new Date(r.created_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: '2-digit', hour: '2-digit', minute: '2-digit' })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Notify tab */}
        {tab === 'notify' && (
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-navy flex items-center gap-2">
                <Mail className="w-4 h-4 text-gold" /> Notify Me List
              </h3>
              <span className="text-sm text-gray-500">{notify.length} emails</span>
            </div>
            {loading ? (
              <div className="p-8 text-center">
                <div className="w-6 h-6 border-2 border-navy/20 border-t-navy rounded-full animate-spin mx-auto" />
              </div>
            ) : notify.length === 0 ? (
              <div className="p-12 text-center text-gray-400 text-sm">No sign-ups yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      {['Email', 'Signed Up'].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {notify.map(r => (
                      <tr key={r.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 text-gray-600 flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 text-gray-400" />{r.email}
                        </td>
                        <td className="px-4 py-3 text-gray-400 text-xs whitespace-nowrap">
                          {new Date(r.created_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: '2-digit', hour: '2-digit', minute: '2-digit' })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
